#!/usr/bin/python3
# Author -Bamidele Adefolaju

def pow(a, b):
    return (a ** b)
